# -*- coding: utf-8 -*-
# Published under the UNLICENSE on https://github.com/python-amazon-mws/python-amazon-mws
from __future__ import absolute_import

from .mws import *  # noqa: F401, F403
from . import mws_patch