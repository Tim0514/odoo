# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import amazon_account
from . import amazon_marketplace
from . import amazon_offer
from . import crm_team
from . import product
from . import res_config_settings
from . import res_partner
from . import sale
from . import stock_location
from . import stock_picking
