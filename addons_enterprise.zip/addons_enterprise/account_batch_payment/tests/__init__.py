# -*- coding: utf-8 -*-

from . import test_account_batch_payment
