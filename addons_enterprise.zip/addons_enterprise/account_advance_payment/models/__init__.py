# -*- coding:utf-8 -*-
from . import account_payment
from . import res_partner
