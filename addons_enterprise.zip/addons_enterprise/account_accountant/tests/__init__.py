# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import test_account_fiscal_year
from . import test_reconciliation_widget
from . import test_bank_reconciliation_widget
from . import test_account_bank_statement
from . import test_tour_reconciliation_widget
