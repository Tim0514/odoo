Custom List View V15
====================

This module will helps to show row number, fixed header, duplicate record and highlight selected record in list view


Credits
=======
Cybrosys Techno Solutions

Author
------
* Cybrosys Techno Solutions <odoo@cybrosys.com>
  Aiswarya J P @ Cybro