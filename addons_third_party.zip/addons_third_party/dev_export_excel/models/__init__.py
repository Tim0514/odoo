# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2015 Devintelle Software Solutions (<http://devintellecs.com>).
#
##############################################################################

from . import dev_export
from . import dev_fields

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

