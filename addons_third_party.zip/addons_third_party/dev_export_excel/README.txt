 Installing Dynamic / Global Export Excel Report For all Application easy. All you need to do is follow the below mentioned points. 

1.First Install Below python Package in your system

sudo easy_install xlsxwriter 

2.Next Go to seeting / apps and search "Dynamic / Global Export Excel Report" and Install 

And, you are done with installation. Congratulations!



