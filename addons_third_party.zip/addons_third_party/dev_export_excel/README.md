Dynamic / Global Export Excel Report For all Application:
=========================================================

First Install Below python Package in your system

Python-Package
---------------

xlsxwriter

sudo easy_install xlsxwriter 

Next Go to seeting / apps and search "Dynamic / Global Export Excel Report" and Install 

And, you are done with installation. Congratulations!


Our Other Apps
----------------

[Our More Apps](https://apps.odoo.com/apps/modules/browse?search=devintelle)


Meet US:
---------

[Google+](https://www.facebook.com/Odoodevintellecs/" target="_blank">DevIntelle)
[FACEBOOK-PAGE](https://plus.google.com/u/0/106859683363969286567)
[YouTube](https://www.youtube.com/channel/UCrmu-T0c8rhMXGuB44bH7gA)
[WEBSITE](https://www.devintellecs.com/)
