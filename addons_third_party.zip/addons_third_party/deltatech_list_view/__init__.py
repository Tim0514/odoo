# ©  2008-2022 Deltatech
# See README.rst file on addons root folder for license details
