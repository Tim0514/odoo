Functions:
 - Blocheaza deschiderea unui item din lista la selecta unui text
