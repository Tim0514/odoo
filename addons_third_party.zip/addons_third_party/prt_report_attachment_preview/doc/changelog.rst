15.0.1.0.3
-----------

- Fix: repeated button actions

15.0.1.0.2
-----------

- Fix: printing via action

15.0.1.0.1
-----------

- Fix: product labels printing

15.0.1.0.0
-----------

- Release for Odoo 15
