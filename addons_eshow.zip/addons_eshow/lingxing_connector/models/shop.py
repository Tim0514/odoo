# Copyright 2020-2022 Max Share Technologies
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0)

from odoo import _, api, fields, models, exceptions
from .lingxing_connector import LingxingConnector as Connector

import logging
_logger = logging.getLogger(__name__)


class Shop(models.Model):
    _inherit = "web.sale.shop"

    lingxing_shop_id = fields.Integer(string="Ling Xing Shop ID",)
    lingxing_shop_name = fields.Char(string="Ling Xing Shop Name",)

    def _prepare_shop_value(self, lingxing_shop_id, lingxing_shop_name, marketplace_id, merchant_id):
        data = {
            "name": lingxing_shop_name,
            "lingxing_shop_id": lingxing_shop_id,
            "lingxing_shop_name": lingxing_shop_name,
            "marketplace_id": marketplace_id,
            "merchant_id": merchant_id,
        }
        return data

    def _import_shops(self):
        lingxing_connector = self.env["connector.lingxing"]
        lingxing_connector.import_web_shops()

    def do_import_shops(self):
        self._import_shops()
        return {
            "warning": {
                "title": "Success",
                "message": "Sync data completed!",
            }
        }
