# Copyright 2018-2019 ForgeFlow, S.L.
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0)

from odoo import _, api, fields, models

class Marketplace(models.Model):
    _inherit = "product.product"

    lingxing_product_id = fields.Integer(string="Ling Xing Product ID", index=True, copy=False)
    lingxing_sync_date = fields.Datetime('Ling Xing Sync Date', readonly=1, index=True, copy=False)

    def _sync_product(self):
        search_domain = [("write_date", ">=", "lingxing_sync_date"), ("sale_ok", "=", True)]
        products = self.env["product.product"].search(search_domain)
