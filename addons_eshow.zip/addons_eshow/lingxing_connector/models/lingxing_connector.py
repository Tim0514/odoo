# Copyright 2020-2022 Max Share Technologies
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0)

from time import gmtime, strftime, time, sleep
from datetime import datetime
from odoo import _, fields

import threading
from typing import Any, Optional

import asyncio

import sys

from odoo import _, exceptions, models
from odoo.tools import OrderedSet
# sys.path.append("..")
from ..openapi.openapi import OpenApiBase
from ..openapi.openapi import ResponseResult
import logging

_logger = logging.getLogger(__name__)

# 当前环境为测试环境，还是生产环境
is_production_enviroment = True

TEST_DOMAIN = "https://openapisandbox.lingxing.com"
TEST_APP_ID = "ak_tQgtvwh74dIq1"
TEST_APP_SECRET = "0OZhqsg22MK0/25CEiTQDg=="

PRODUCTION_DOMAIN = "https://openapi.lingxing.com"
PRODUCTION_APP_ID = "ak_f6yeEe7UTPh9g"
PRODUCTION_APP_SECRET = "3jKW34DKf8cUbA8xaaUqIg=="

if is_production_enviroment:
    ACCESS_DOMAIN = PRODUCTION_DOMAIN
    APP_ID = PRODUCTION_APP_ID
    APP_SECRET = PRODUCTION_APP_SECRET
else:
    ACCESS_DOMAIN = TEST_DOMAIN
    APP_ID = TEST_APP_ID
    APP_SECRET = TEST_APP_SECRET


class ConnectorError(Exception):
    """
    Main Exception class
    """
    # Allows quick access to the response object.
    # Do not rely on this attribute, always check if its not None.
    response_result = None


class SameActionRunningError(Exception):
    """
    This error will be occured when same action is already running.
    """
    request_action = None


class LingxingConnector(models.Model):
    _name = "connector.lingxing"
    _description = "Lingxing Connector"
    _order = "name"

    access_token = None
    refresh_token = None
    expires_in = None
    last_refresh_token_time = None

    name = fields.Char("Name", index=True)
    action_description = fields.Char("Description")
    route = fields.Char("Route")
    method = fields.Char("Method")
    max_concurrency = fields.Integer("Max Concurrency", default=1)
    related_model_id = fields.Many2one("ir.model", string="Related Model")
    action_type = fields.Selection([("export", "Export"), ("import", "Import")], string="Action Type")
    start_time = fields.Datetime("Start Time", default=fields.Datetime.to_datetime("2000-01-01 00:00:00"))
    end_time = fields.Datetime("End Time", default=fields.Datetime.to_datetime("2000-01-01 00:00:00"))
    last_sync_time = fields.Datetime("Last Sync Time")
    last_sync_result = fields.Selection([("fail", "Fail"), ("success", "Success")], string="Last Sync Result")
    last_success_sync_time = fields.Datetime("Last Success Sync Time")

    # 当前正在运行的同步动作，用于防止相同的操作被同时执行。导致数据错误。
    running_actions = {}

    @staticmethod
    def _raise_connector_error(message, request_action: str = None, response_result: ResponseResult = None, error=None):
        """ Build an error log from a error response, if any, and raise it. """
        error_log = message
        # if request_action:
        #     error_log += "\nAction: %s" % request_action
        if response_result:
            error_log += "\n %s: %s" % (
                response_result.code,
                response_result.message
            )
        if error:
            error_log += "\n Stack Error: %s" % str(error)

        error = ConnectorError(error_log)
        error.response_result = response_result

        raise error

    @staticmethod
    def set_action_start(action_name):
        lock = threading.Lock()
        with lock:
            if action_name in LingxingConnector.running_actions:
                if LingxingConnector.running_actions[action_name]:
                    error = SameActionRunningError("Same action is running, please try again later.")
                    error.request_action = action_name
                    raise error
                    # LingxingConnector._raise_connector_error("Same action is running, please try again later.",
                    #                                          action_name)
            else:
                LingxingConnector.running_actions[action_name] = True
        return True

    @staticmethod
    def set_action_complete(action_name):
        lock = threading.Lock()
        with lock:
            LingxingConnector.running_actions[action_name] = False
        return True

    @staticmethod
    async def _refresh_access_token():
        try:
            current_time = time()

            if (not LingxingConnector.access_token) \
                    or (not LingxingConnector.last_refresh_token_time) \
                    or current_time - LingxingConnector.last_refresh_token_time > 6000:
                op_api = OpenApiBase(ACCESS_DOMAIN, APP_ID, APP_SECRET)
                response_data = await op_api.generate_access_token()
                LingxingConnector.access_token = response_data.access_token
                LingxingConnector.refresh_token = response_data.refresh_token
                LingxingConnector.expires_in = response_data.expires_in
                LingxingConnector.last_refresh_token_time = current_time

            return LingxingConnector.access_token

        except Exception as error:
            LingxingConnector._raise_connector_error(
                "Error Obtain Token From Lingxing Server",
                request_action="get_access_token",
                error=error
            )

    def make_single_request(
            self,
            req_params: Optional[dict] = None,
            req_body: Optional[dict] = None,
            **kwargs) -> ResponseResult:
        """
        发送单次请求，通常用于下载数据。
        如果出现重复下载的情况，则多次调用此方法。
        :param req_params:
        :param req_body:
        :param kwargs:
        :return:
        """

        # 获取接口路径和Method
        request_action = self.name
        route = self.route
        method = self.method

        try:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

            # 刷新Token
            loop.run_until_complete(LingxingConnector._refresh_access_token())

            op_api = OpenApiBase(ACCESS_DOMAIN, APP_ID, APP_SECRET)

            task1 = loop.create_task(
                op_api.request(LingxingConnector.access_token, route, method, req_params, req_body, **kwargs)
            )

            loop.run_until_complete(task1)

            response = task1.result()

            if response.code != 0:
                LingxingConnector._raise_connector_error(
                    "Error occured when synchronizing with Lingxing Server.",
                    request_action=request_action,
                    response_result=response,
                )
            else:
                return response

        except ConnectorError as error:
            raise error
        except BaseException as error:
            LingxingConnector._raise_connector_error(
                "Error Connecting To Lingxing Server",
                request_action=request_action,
                error=error
            )

    def make_multi_request(
            self,
            req_params: Optional[dict] = None,
            req_body_list: Optional[list] = None,
            **kwargs) -> list[ResponseResult]:
        """
        发送多次请求，通常用于上传数据。
        :param req_params:
        :param req_body_list: req_body的列表
        :param kwargs:
        :return:
        """

        # 获取接口路径和Method
        request_action = self.name
        route = self.route
        method = self.method
        max_concurrency = self.max_concurrency

        # 返回值列表
        result_list = []

        try:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

            # 刷新Token
            loop.run_until_complete(LingxingConnector._refresh_access_token())

            op_api = OpenApiBase(ACCESS_DOMAIN, APP_ID, APP_SECRET)

            # 总请求数
            total_requests = len(req_body_list)

            async def _run_multi_tasks(tasks):
                rtn = await asyncio.wait(tasks, return_when=asyncio.tasks.ALL_COMPLETED)
                await asyncio.sleep(2)
                return rtn

            i = 0
            while i < total_requests:
                j = 0
                tasks = []
                while j < max_concurrency and (i + j) < total_requests:
                    req_body = req_body_list[i + j]
                    task = loop.create_task(
                        op_api.request(LingxingConnector.access_token, route, method, req_params, req_body,
                                       **kwargs),
                        name="%s" % (str(100000 + i + j))
                    )
                    tasks.append(task)
                    j = j + 1
                task_result_set, result_list_pending = loop.run_until_complete(_run_multi_tasks(tasks))
                # sleep(10)

                # 返回的task_result_set是无序的集合，需要转换成有序的列表
                task_result_dict = {}
                task_result_list = []
                for task_result in task_result_set:
                    task_result_dict[task_result.get_name()] = task_result
                sort_keys = sorted(task_result_dict.keys())
                for key in sort_keys:
                    task_result = task_result_dict[key]
                    task_result_list.append(task_result)

                result_list_temp = []
                for task_result in task_result_list:
                    if task_result.exception():
                        # 如果任务本身发生错误，无法正确返回response_result，则创建一个
                        response_result = ResponseResult()
                        response_result.code = 999999
                        response_result.message = "Odoo Side Error"
                        response_result.error_details = str(task_result.exception())
                        result_list_temp.append(response_result)
                    else:
                        result_list_temp.append(task_result.result())
                result_list = result_list + result_list_temp
                i = i + j

            loop.close()

            return result_list

        except ConnectorError as error:
            raise error
        except BaseException as error:
            LingxingConnector._raise_connector_error(
                "Error Connecting To Lingxing Server",
                request_action=request_action,
                error=error
            )

    def _get_model_id(self, model_name):
        model_id = self.env['ir.model']
        return model_id.search([('model', '=', model_name)])

    def _get_data_sync_time_dict(self):
        """
        获取同步数据行的相关同步时间
        :param request_action:
        :param model_name:
        :param action_type: 需要返回导出时间，还是导入时间
        :return: {res_id:sync_time}
        """
        request_action = self.name
        model_id = self.related_model_id.id
        action_type = self.action_type

        data_sync_info_obj = self.env["connector.data.sync.info"]
        domain = [("operation_name", "=", request_action), ("model_id", "=", model_id)]
        data_info_list = data_sync_info_obj.search(domain, order="res_id")

        data_info_dict = {}
        for data_info in data_info_list:
            if action_type == "import":
                data_info_dict[data_info.res_id] = data_info.last_import_time
            else:
                data_info_dict[data_info.res_id] = data_info.last_export_time
        return data_info_dict

    def _update_data_sync_time(self, res_ids=Optional[list], sync_time=fields.Datetime.now()):
        """
        更新相关记录的导入或导出时间
        :param request_action:
        :param model_name:
        :param action_type:
        :param sync_time:
        :param res_ids: 模型数据的ID列表
        :return:
        """

        request_action = self.name
        action_type = self.action_type
        model_id = self.related_model_id.id

        data_sync_info_obj = self.env["connector.data.sync.info"]
        domain = [("operation_name", "=", request_action), ("model_id", "=", model_id)]

        # 首先读取出全部记录
        existing_records = data_sync_info_obj.search(domain, order="res_id")

        # 需要添加的记录
        records_to_add: list[dict] = []

        # 需要更新的记录，元素为 更新字段的id
        records_to_update = OrderedSet()

        for res_id in res_ids:
            existing_data = existing_records.filtered(lambda r: r.res_id == res_id)
            if existing_data:
                records_to_update.add(existing_data.id)
            else:
                if action_type == "import":
                    records_to_add.append(
                        {
                            "operation_name": request_action,
                            "model_id": model_id,
                            "res_id": res_id,
                            "last_import_time": sync_time,
                            "last_export_time": False,
                        })
                else:
                    records_to_add.append(
                        {
                            "operation_name": request_action,
                            "model_id": model_id,
                            "res_id": res_id,
                            "last_import_time": False,
                            "last_export_time": sync_time,
                        })

        if action_type == "import":
            data_sync_info_obj.browse(records_to_update).sudo().write({"last_import_time": sync_time})
        else:
            data_sync_info_obj.browse(records_to_update).sudo().write({"last_export_time": sync_time})

        data_sync_info_obj.sudo().create(records_to_add)

    def _get_last_action_time(self, request_action):
        """
            从log book 中读取最后一次成功操作的时间，如果没有找到，则默认2010年1月1日
        :return:
        """
        last_action_time = datetime.strptime('2010-01-01', '%Y-%m-%d')
        log_book = self.env["eshow.log.book"]
        log_book = log_book.search(
            [
                ("log_module", "=", "lingxing_connector"),
                ("operation_name", "=", request_action),
                ("action_state", "=", "success"),
            ],
            order="start_date desc",
            limit=1
        )
        if log_book:
            last_action_time = log_book[0].start_date
        return last_action_time

    def _init_log_book(self):
        # 初始化log_book
        log_book = self.env["eshow.log.book"]
        log_book = log_book.init_log_book('lingxing_connector', self.name)
        return log_book

    def import_web_shops(self):
        """
        下载店铺数据，
        这是最简单的一次性下载数据的样例。适用于基础数据的下载
        :return: log_book
        """
        request_action = self.name
        model_id = self.related_model_id.id

        # 初始化log_book
        log_book = self._init_log_book()

        # action_state 默认为“success”, 如果中间发生错误则改为“error”
        action_state = "success"

        try:
            # 设置同步开始
            LingxingConnector.set_action_start(request_action)

            # 请求数据
            response_result = self.make_single_request()
            shop_list = response_result.data

            # 查询下载的信息中，marketplace数据是否已经存在，如果没有，则报错
            marketplace_to_add = {}
            marketplace_obj = self.env["web.sale.marketplace"]
            for shop_dict in shop_list:
                if not str(shop_dict["mid"]) in marketplace_to_add:
                    marketplace = marketplace_obj.search([('lingxing_marketplace_id', '=', shop_dict["mid"])], limit=1)
                    if not marketplace:
                        marketplace_to_add[str(shop_dict["mid"])] = "Country: %s - Region: %s - Shop Name: %s" % (
                            shop_dict["country"], shop_dict["region"], shop_dict["name"])
            if marketplace_to_add:
                error_msg = "Unable to find Lingxing Marketplace in Marketplace."
                error_msg += "\n Please add record in Marketplace First"
                for marketplace_to_add_key, marketplace_to_add_value in marketplace_to_add.items():
                    error_msg += "\n MID: %s - %s" % (marketplace_to_add_key, marketplace_to_add_value)
                LingxingConnector._raise_connector_error(error_msg, request_action)

            # 导入店铺信息，如果没有，则新建，如果已有，则更新名称
            shops_to_update = []
            shops_to_ignore = []
            shops_to_add = []

            log_line_val_list = []

            shop_obj = self.env["web.sale.shop"]
            for shop_dict in shop_list:
                res_id = False
                code_ref = False
                name_ref = False

                try:
                    exist_shop = shop_obj.search([('lingxing_shop_id', '=', shop_dict["sid"])], limit=1)
                    if exist_shop:
                        res_id = exist_shop
                        code_ref = exist_shop.shop_code
                        name_ref = exist_shop.name
                        if exist_shop.name != shop_dict["name"]:
                            exist_shop.write({
                                "lingxing_shop_name": shop_dict["name"],
                            })
                            shops_to_update.append(exist_shop)

                            log_line_val_list.append(log_book._prepare_log_line(
                                code_ref=code_ref,
                                name_ref=name_ref,
                                action_state="success",
                                error_message=False,
                                ext_message="Data updated.",
                                model_id=model_id,
                                res_id=res_id,
                            ))
                        else:
                            shops_to_ignore.append(exist_shop)

                            log_line_val_list.append(log_book._prepare_log_line(
                                code_ref=code_ref,
                                name_ref=name_ref,
                                action_state="success",
                                error_message=False,
                                ext_message="No need to update.",
                                model_id=model_id,
                                res_id=res_id,
                            ))
                    else:
                        marketplace = marketplace_obj.search([('lingxing_marketplace_id', '=', shop_dict["mid"])],
                                                             limit=1)
                        shop_value = shop_obj._prepare_shop_value(
                            shop_dict["sid"],
                            shop_dict["name"],
                            marketplace.id,
                            shop_dict["seller_id"],
                        )
                        new_shop = shop_obj.create(shop_value)
                        res_id = new_shop
                        code_ref = new_shop.shop_code
                        name_ref = new_shop.name

                        log_line_val_list.append(log_book._prepare_log_line(
                            code_ref=code_ref,
                            name_ref=name_ref,
                            action_state="success",
                            error_message=False,
                            ext_message="New data added.",
                            model_id=model_id,
                            res_id=res_id,
                        ))
                        shops_to_add.append(new_shop)

                except Exception as error:
                    action_state = "fail"
                    model_id = self._get_model_id("web.sale.shop")
                    log_line_val_list.append(log_book._prepare_log_line(
                        code_ref=code_ref,
                        name_ref=name_ref,
                        action_state=action_state,
                        error_message=str(error),
                        ext_message=False,
                        model_id=model_id,
                        res_id=res_id,
                    ))

            total_record_count = len(shop_list)
            success_record_count = len(shops_to_update) + len(shops_to_add)
            ignore_record_count = len(shops_to_ignore)
            fail_record_count = total_record_count - success_record_count - ignore_record_count

            # 添加明细行日志
            log_book.add_log_lines(log_line_val_list)

        except SameActionRunningError as error:
            _logger.exception(error)
            log_book.update_log_book_result("fail", error_message=str(error))
            raise error
        except Exception as error:
            _logger.exception(error)
            log_book.update_log_book_result("fail", error_message=str(error))
            LingxingConnector.set_action_complete(request_action)
            raise error
        else:
            error_message = False
            if action_state == "fail":
                error_message = "See error in line data."
            log_book.update_log_book_result(
                action_state,
                total_record_count=total_record_count,
                success_record_count=success_record_count,
                fail_record_count=fail_record_count,
                ignore_record_count=ignore_record_count,
                error_message=error_message, ext_message=None)
            LingxingConnector.set_action_complete(request_action)
        finally:
            return log_book

    def _get_export_local_products(self):
        request_action = "export_local_products"
        model_name = "product.product"
        import_or_export = "export"

        # last_action_time = self._get_last_action_time(request_action)
        data_sync_time_dict = self._get_data_sync_time_dict()

        product_obj = self.env["product.product"]
        products = product_obj.search(
            [
                ("sale_ok", "=", True),
                # ("write_date", ">=", last_action_time),
                # ("default_code", "in", ["ESG2-CC02S-BLMD13", "ESG2-GN07-1020", "ESG2-TE02S-MX100"])
            ],
            order="default_code, id",
            # limit=50,
        )

        lx_product_list = []

        for product in products:
            if (not (product.id in data_sync_time_dict)) or data_sync_time_dict[product.id] < product.write_date:
                lx_product_dict = {
                    "sku": product.default_code,
                    "product_name": product.name,
                    "unit": product.uom_id.name,
                    "status": 1,
                    "cg_price": product.list_price,
                    "cg_product_length": round(product.length / 10, 2),
                    "cg_product_width": round(product.width / 10, 2),
                    "cg_product_height": round(product.height / 10, 2),
                    "cg_product_net_weight": round(product.weight * 1000, 2),
                    "cg_product_gross_weight": round(product.weight * 1000, 2),
                    "cg_package_length": round(product.length / 10, 2),
                    "cg_package_width": round(product.width / 10, 2),
                    "cg_package_height": round(product.height / 10, 2),
                    "odoo_product_id": product.id,
                    # "bg_customs_import_price": product.destination_declare_price,
                }
                lx_product_list.append(lx_product_dict)
        return lx_product_list

    def export_local_products(self):
        """
        上传本地产品到领星系统
        这是批量上传产品的样例
        :return: log book
        """
        request_action = self.name
        model_id = self.related_model_id.id

        # 初始化log_book
        log_book = self._init_log_book()

        # 同步成功的id列表
        success_res_id_list = []

        # action_state 默认为“success”, 如果中间发生错误则改为“error”
        action_state = "success"

        try:
            # 设置同步开始
            LingxingConnector.set_action_start(request_action)

            lx_product_list = self._get_export_local_products()

            # 请求数据
            result_list = self.make_multi_request(req_body_list=lx_product_list)

            total_record_count = len(result_list)
            success_record_count = 0
            ignore_record_count = 0
            fail_record_count = 0

            i = 0
            log_line_val_list = []
            for result in result_list:
                product_data = lx_product_list[i]

                if result.code != 0:
                    action_state = "fail"
                    detail_action_state = "fail"
                    error_message = "%s - %s" % (result.code, result.message)
                    ext_message = str(result.error_details)
                    fail_record_count = fail_record_count + 1
                else:
                    detail_action_state = "success"
                    error_message = False
                    ext_message = False

                    success_record_count = success_record_count + 1

                    # 添加到成功id列表中
                    success_res_id_list.append(product_data["odoo_product_id"])

                # 无论成功还是失败，均添加明细行日志
                log_line_val_list.append(log_book._prepare_log_line(
                    code_ref=product_data["sku"],
                    name_ref=product_data["product_name"],
                    action_state=detail_action_state,
                    error_message=error_message,
                    ext_message=ext_message,
                    model_id=model_id,
                    res_id=product_data["odoo_product_id"],
                ))

                i = i + 1

            # 添加明细行日志
            log_book.add_log_lines(log_line_val_list)

            # 将数据行的更新时间写入同步成功的data_sync_info表中
            self._update_data_sync_time(success_res_id_list)

        except SameActionRunningError as error:
            _logger.exception(error)
            log_book.update_log_book_result("fail", error_message=str(error))
            raise error
        except Exception as error:
            _logger.exception(error)
            log_book.update_log_book_result("fail", error_message=str(error))
            LingxingConnector.set_action_complete(request_action)
            raise error
        else:
            error_message = False
            if action_state == "fail":
                error_message = "See error in line data."
            log_book.update_log_book_result(
                action_state,
                total_record_count=total_record_count,
                success_record_count=success_record_count,
                fail_record_count=fail_record_count,
                ignore_record_count=ignore_record_count,
                error_message=error_message, ext_message=None)
            LingxingConnector.set_action_complete(request_action)
        finally:
            return log_book

    def import_shop_products(self, start_time=False, end_time=False):
        """
        导入店铺产品数据
        这是分页下载和指定数据日期段下载的样例，例如下载订单。
        :param start_time: 导入的数据的更新时间从start_time开始，如果为False则使用数据库记录的end_time
        :param end_time: 导入的数据的更新时间到end_time结束，如果为False则使用当前时间
        :return: log_book
        """
        request_action = self.name
        model_id = self.related_model_id.id

        # 初始化log_book
        log_book = self._init_log_book()

        # action_state 默认为“success”, 如果中间发生错误则改为“error”
        action_state = "success"

        # sync_start_time 用于参数的 各种end_time
        sync_start_time = fields.Datetime.now()

        # 如果没有传入start_time, 则取上次结束的时间
        if not start_time:
            if self.end_time:
                start_time = self.end_time
            else:
                start_time = datetime.strptime("2000-01-01 00:00:00", '%Y-%m-%d %H:%M:%S')

        # 如果没有传入end_time, 则取本次同步时间
        if not end_time:
            end_time = sync_start_time

        try:
            # 设置同步开始
            LingxingConnector.set_action_start(request_action)

            web_shops = self.env["web.sale.shop"].search([("enable_exchange_data", "=", True)], order="lingxing_shop_id")
            web_shop_ids = web_shops.mapped("lingxing_shop_id")
            web_shop_ids = ",".join(map(str, web_shop_ids))

            length = 1000
            offset = 0
            total = 1

            result_list = []
            while total != 0 and offset + 1 <= total:
                req_body = {
                    "sid": web_shop_ids,
                    "offset": offset,
                    "length": length,
                    "is_pair": 1,
                    "pair_update_start_time": "2000-01-01 00:00:00",
                    "pair_update_end_time": end_time.strftime('%Y-%m-%d %H:%M:%S'),
                    "listing_update_start_time": start_time.strftime('%Y-%m-%d %H:%M:%S'),
                    "listing_update_end_time": end_time.strftime('%Y-%m-%d %H:%M:%S'),
                }

                # 请求数据
                response_result = self.make_single_request(req_body=req_body)

                total = response_result.total

                if total > 0:
                    result_list.extend(response_result.data)
                    total = response_result.total
                    offset = offset + length

            log_line_val_list = []

            shop_product_obj = self.env["web.sale.shop.product"]

            shop_product_ids_added = []
            shop_product_ids_updated = []
            product_vals_fail = []

            # 用于临时存储货币类型
            currency_dict = {}
            # 用于临时shop
            lingxing_shop_dict = {}

            for result in result_list:
                try:
                    detail_action_state = "success"
                    error_message = ext_message = False

                    # 创建新的product_vals 用于创建或更新产品信息
                    product_vals = {}
                    product_vals["seller_sku"] = result["seller_sku"]
                    product_vals["product_asin"] = result["asin"]
                    product_vals["product_listing_id"] = result["listing_id"]
                    product_vals["product_fnsku"] = result["fnsku"]
                    product_vals["parent_asin"] = result["parent_asin"]
                    product_vals["shop_product_name"] = result["item_name"]
                    product_vals["seller_rank"] = result["seller_rank"]
                    product_vals["seller_rank_category"] = result["seller_category"]
                    product_vals["review_num"] = result["review_num"]
                    product_vals["review_star"] = result["last_star"]
                    product_vals["fulfillment_channel_type"] = result["fulfillment_channel_type"]
                    product_vals["afn_fulfillable_quantity"] = result["afn_fulfillable_quantity"]
                    product_vals["reserved_fc_transfers"] = result["reserved_fc_transfers"]
                    product_vals["reserved_fc_processing"] = result["reserved_fc_processing"]
                    product_vals["reserved_customerorders"] = result["reserved_customerorders"]
                    product_vals["afn_inbound_shipped_quantity"] = result["afn_inbound_shipped_quantity"]
                    product_vals["afn_unsellable_quantity"] = result["afn_unsellable_quantity"]
                    product_vals["afn_inbound_working_quantity"] = result["afn_inbound_working_quantity"]
                    product_vals["afn_inbound_receiving_quantity"] = result["afn_inbound_receiving_quantity"]

                    product_vals["listing_update_time"] = datetime.strptime(result["listing_update_date"], "%Y-%m-%d %H:%M:%S")
                    product_vals["pair_update_time"] = datetime.strptime(result["pair_update_time"], "%Y-%m-%d %H:%M:%S")

                    if result["status"] == 1:
                        product_vals["state"] = "normal"
                    else:
                        product_vals["state"] = "stop"

                    if result["is_delete"] == 1:
                        product_vals["is_deleted"] = True
                    else:
                        product_vals["is_deleted"] = False

                    if detail_action_state == "success":
                        # 检查Shop是否已经存在。
                        if result["sid"] in lingxing_shop_dict:
                            product_vals["shop_id"] = lingxing_shop_dict[result["sid"]]
                        else:
                            lingxing_shop_id = result["sid"]
                            web_shop = self.env["web.sale.shop"].search([("lingxing_shop_id", "=", lingxing_shop_id)], limit=1)
                            if web_shop:
                                lingxing_shop_dict[lingxing_shop_id] = web_shop.id
                                product_vals["shop_id"] = web_shop.id
                            else:
                                action_state = "fail"
                                detail_action_state = "fail"
                                error_message = "Web Shop, %s, is not found in database." % (result["sid"])

                    if detail_action_state == "success":
                        # 检查currency是否已经存在
                        if result["currency_code"] in currency_dict:
                            product_vals["currency_id"] = currency_dict[result["currency_code"]]
                        else:
                            currency = self.env["res.currency"].search([("name", "=", result["currency_code"])], limit=1)
                            if currency:
                                currency_dict[currency.name] = currency.id
                                product_vals["currency_id"] = currency.id
                            else:
                                action_state = "fail"
                                detail_action_state = "fail"
                                error_message = "Currency, %s, is not found in database." % (result["currency_code"])

                    if detail_action_state == "success":
                        # 如果有pair_update_time，则表示产品已配对。
                        if "pair_update_time" in result and result["pair_update_time"] != "":
                            # 检查product是否已经存在
                            product_default_code = result["local_sku"]
                            product = self.env["product.product"].search([("default_code", "=", product_default_code)], limit=1)
                            if product:
                                product_vals["product_id"] = product.id
                            else:
                                action_state = "fail"
                                detail_action_state = "fail"
                                error_message = "Product, %s, is not found in database." % (result["local_sku"])
                        else:
                            # 未配对产品
                            product_vals["product_id"] = False

                    if detail_action_state == "success":
                        domain = [("shop_id", "=", product_vals["shop_id"]), ("seller_sku", "=", product_vals["seller_sku"])]
                        shop_product = shop_product_obj.search(domain, limit=1)
                        if shop_product:
                            # shop_product已经存在，则更新。
                            shop_product.write(product_vals)
                            shop_product_ids_updated.append(shop_product.id)
                        else:
                            shop_product = shop_product_obj.create(product_vals)
                            shop_product_ids_added.append(shop_product.id)

                        # 添加明细行日志
                        log_line_val_list.append(log_book._prepare_log_line(
                            code_ref=product_vals["seller_sku"],
                            name_ref=product_vals["shop_product_name"],
                            action_state=detail_action_state,
                            error_message=error_message,
                            ext_message=ext_message,
                            model_id=model_id,
                            res_id=shop_product.id,
                        ))
                    else:
                        product_vals_fail.append(product_vals)
                        # 添加明细行日志
                        log_line_val_list.append(log_book._prepare_log_line(
                            code_ref=product_vals["seller_sku"],
                            name_ref=product_vals["shop_product_name"],
                            action_state=detail_action_state,
                            error_message=error_message,
                            ext_message=ext_message,
                            model_id=model_id,
                            res_id=False,
                        ))
                except Exception as error:
                    product_vals_fail.append(result)
                    # 添加明细行日志
                    log_line_val_list.append(log_book._prepare_log_line(
                        code_ref=result["seller_sku"],
                        name_ref=result["item_name"],
                        action_state="fail",
                        error_message="未捕捉到的错误: %s" % str(error),
                        ext_message=str(result),
                        model_id=model_id,
                        res_id=False,
                    ))

            success_record_count = len(shop_product_ids_added) + len(shop_product_ids_updated)
            fail_record_count = len(product_vals_fail)
            ignore_record_count = 0
            total_record_count = success_record_count + fail_record_count + ignore_record_count

            # 添加明细行日志
            log_book.add_log_lines(log_line_val_list)

            # 将数据行的更新时间写入同步成功的data_sync_info表中
            self._update_data_sync_time(
                res_ids=shop_product_ids_updated+shop_product_ids_added,
                sync_time=sync_start_time
            )

            if action_state == "fail":
                self.sudo().last_sync_result = action_state
                self.sudo().last_sync_time = sync_start_time

                error_message = "See error in line data."
                ext_message = False
            else:
                self.sudo().start_time = start_time
                self.sudo().end_time = end_time
                self.sudo().last_sync_result = action_state
                self.sudo().last_sync_time = sync_start_time
                self.sudo().last_success_sync_time = sync_start_time

                error_message = False
                ext_message = False

            log_book.update_log_book_result(
                action_state,
                total_record_count=total_record_count,
                success_record_count=success_record_count,
                fail_record_count=fail_record_count,
                ignore_record_count=ignore_record_count,
                error_message=error_message, ext_message=ext_message)
            LingxingConnector.set_action_complete(request_action)

        except SameActionRunningError as error:
            _logger.exception(error)
            log_book.update_log_book_result("fail", error_message=str(error))
            raise error
        except Exception as error:
            _logger.exception(error)
            log_book.update_log_book_result("fail", error_message=str(error))
            LingxingConnector.set_action_complete(request_action)
            raise error
        finally:
            return log_book
