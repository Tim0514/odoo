Purchase plans are accessible from the 'Purchase' menu.

Users can access the list of Purchase Plans.

It is possible to filter plans by its approval status.
