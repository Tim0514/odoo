To configure the product follow this steps:

#. Go to a product form.
#. Go to *Inventory* tab.
#. Check the box *Purchase Plan* along with the route *Buy*.

With this configuration, whenever a procurement order is created and the supply
rule selected is 'Buy' the application will create a Purchase Request instead
of a Purchase Order.
