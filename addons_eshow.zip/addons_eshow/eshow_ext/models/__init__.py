from . import product
from . import product_template
from . import product_attribute
from . import res_partner
from . import mrp_bom
from . import stock_warehouse
from . import stock_picking
from . import stock_move
from . import stock_rule
from . import stock_orderpoint
from . import res_config_settings
from . import purchase
from . import sale_order
from . import account_move




