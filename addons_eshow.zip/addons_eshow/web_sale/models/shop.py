# Copyright 2020-2022 Max Share Technologies
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0)

from odoo import _, api, fields, models

class Shop(models.Model):
    _name = "web.sale.shop"
    _description = "Shop"
    _order = "name"

    name = fields.Char(
        string="Shop Name",
        index=True,
    )

    # 店铺编码
    shop_code = fields.Char(string='Shop Code')

    # 所属市场
    marketplace_id = fields.Many2one(comodel_name="web.sale.marketplace", string='Marketplace')

    # 平台商家ID
    merchant_id = fields.Char(string='Shop Merchant ID')

    # default_warehouse_id = fields.Many2one(comodel_name="stock.warehouse", string='Web Shop Default Warehouse')

    auth_token = fields.Char(string='Authorization Token')

    access_key = fields.Char(string='Access Key')

    secret_key = fields.Char(string="Secret Key")

    # 允许同步数据
    enable_exchange_data = fields.Boolean("Enable Exchange Data", default=False)

    default_warehouse_id = fields.Many2one("stock.warehouse")
