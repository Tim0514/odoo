from . import res_partner
from . import marketplace
from . import shop
from . import shop_product
from . import shop_product_asin
from . import shop_product_monthly_stat
from . import shop_product_weekly_stat
from . import shipping_schedule
from . import shipping_schedule_group
from . import shop_inventory
from . import shop_warehouse
from . import shipping_method
from . import stock_picking
from . import stock_move
from . import shop_sale_data
from . import mrp_mps

