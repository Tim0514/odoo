# -*- coding: utf-8 -*-

from collections import namedtuple, OrderedDict, defaultdict

from dateutil.relativedelta import relativedelta

from odoo import models, api, fields
from odoo.tools import float_compare, float_round

class StockPicking(models.Model):
    _inherit = 'stock.picking'

    def _prepare_subcontract_mo_vals(self, subcontract_move, bom):
        """
            修正，mrp_subcontracting模块中stockpicking中的同名方法，改成根据父节点的group
        """
        vals = super(StockPicking, self)._prepare_subcontract_mo_vals(subcontract_move, bom)

        if self.group_id:
            vals["procurement_group_id"] = self.group_id.id
        else:
            del vals["procurement_group_id"]
        return vals
